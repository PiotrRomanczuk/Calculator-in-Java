package main;

public class MainClass02 {

	public static void main(String[] args) {
		/*The class Math provides some useful attributes and methods*/
		double e = Math.E;
		double pi = Math.PI;
		System.out.println("Euler's number e=" + e);
		System.out.println("pi=" + pi);
		
		System.out.println("########################################################");
		
		double number = 2.0;
		double power = 3;
		double result = Math.pow(number, power);
		System.out.println("result=" + result);
		
	

	}//main
}//class
