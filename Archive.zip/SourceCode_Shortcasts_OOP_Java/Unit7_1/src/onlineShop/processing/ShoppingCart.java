package onlineShop.processing;

public class ShoppingCart {
	/*You can also leave out completely
	 * the definition of the standard constructor.
	 * In this case an empty standard constructor is
	 * implicitly added by the Java compiler.
	 * Even if you don't see such a constructor here in the source code, 
	 * it can still be invoked with the new-operator
	 * and it will create an object -instance of this class
	 * */
}
