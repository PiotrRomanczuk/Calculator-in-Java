package package02;

public class Customer {

}
