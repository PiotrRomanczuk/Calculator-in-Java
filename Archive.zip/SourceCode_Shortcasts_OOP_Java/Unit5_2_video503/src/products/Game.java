package products;

public class Game extends Product{

	//attributes
	private Author author;

	//getters and setters
	public Author getAuthor() {
		return author;
	}

	public void setAuthor(Author author) {
		this.author = author;
	}
	
	
}//class
