package products;

public class Film extends Product{
	
	//attributes
	private String director;

	//getters and setters
	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}
		
}//class
