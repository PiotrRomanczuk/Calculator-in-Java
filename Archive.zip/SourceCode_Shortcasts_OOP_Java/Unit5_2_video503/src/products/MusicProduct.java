package products;

public class MusicProduct extends Product{
	
	//attributes
	private String performer;

	//getters and setters
	public String getPerformer() {
		return performer;
	}

	public void setPerformer(String performer) {
		this.performer = performer;
	}
		
}//class
