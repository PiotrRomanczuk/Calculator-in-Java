package onlineShop.products;

public class Book extends Product{
//public class Book{
	
	public static void main(String[] args) {
//		Book myBook01 = new Book();
//		myBook01.

	}//main
	
}//class
