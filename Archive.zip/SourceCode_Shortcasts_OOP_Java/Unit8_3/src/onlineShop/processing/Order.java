package onlineShop.processing;

public class Order {

}
