package onlineShop.users;

public class Admin {

}
