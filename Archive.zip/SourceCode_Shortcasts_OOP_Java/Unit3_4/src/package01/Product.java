package package01;

public class Product {

}
