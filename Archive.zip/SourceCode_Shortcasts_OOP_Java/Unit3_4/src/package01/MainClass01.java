package package01;

public class MainClass01 {
	

//	public int addToShoppingCart(Product product) {return 0;}
//	
//	public int addToShoppingCart(Product product, int quantity) {return 0;}
	
	public int addToShoppingCart(Product product){
		//execute some actions to add the product
		//and return 0 if everything was correct
		return 0;
	}
	
	public int addToShoppingCart(Product product, int quantity){
		//execute some actions to add the product,
		//in the specified quantity
		//and return 0 if everything was correct
		return 0;
	}
	

	public boolean pay(boolean test) {return false;}
	
	//uncomment next line to induce error
	//public void pay(boolean test) {return false;}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}//main

}//class
