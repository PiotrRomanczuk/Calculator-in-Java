package package01;

public class Customer {
	
	//attributes
	private String lastname;
	private String firstname;
	private String sex;
	private String birthdate;
	
	private boolean isPremiumCustomer = false;
	private int quantityOfPurchase = 0;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}//end of class




