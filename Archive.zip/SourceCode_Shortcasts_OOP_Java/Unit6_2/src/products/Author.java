package products;

public class Author {
	/*This class is needed in order to
	 * properly reflect the example described in the course book
	 * */
	
	//attributes
	private String authorName;

	//getters and setters
	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	
	
}//class
