package interfaces;

public interface Move {
	public void moveForward();
}
