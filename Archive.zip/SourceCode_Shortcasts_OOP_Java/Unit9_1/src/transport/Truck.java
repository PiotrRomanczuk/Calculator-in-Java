package transport;

import interfaces.Vehicle;

public class Truck implements Vehicle{

	@Override
	public void honk() {
		// TODO Auto-generated method stub
		System.out.println("I am a Truck, and I HOOOOONK");
	}
	
	
	//System.out.println("I am a Truck, and I HOOOOONK");	
}//class
