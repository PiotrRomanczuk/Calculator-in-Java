package onlineShop;

import onlineShop.users.PremiumCustomer;

public class MainClass {

	public static void main(String[] args) {

		//Declaring some values 
		//for the attributes of the customer
		String lName01 = "Customer";
		String fName01 = "Premium";
		
		/*Instantiating an object of type PremiumCustomer,
		 * by invoking the overloaded constructor
		 * */
		PremiumCustomer premiumCustomer = new PremiumCustomer(lName01,fName01);
		
		System.out.println("Displaying the information for the premiumCustomer");
		System.out.println("Last name=" + premiumCustomer.getLastName());
		System.out.println("First name=" + premiumCustomer.getFirstName());
		System.out.println("Birthdate=" + premiumCustomer.getBirthdate());
		System.out.println("Gender=" + premiumCustomer.getSex());
		System.out.println("customer01.getMinimumOrderValue()=" + premiumCustomer.getMinimumOrderValue());
	
	}//main

}//class
