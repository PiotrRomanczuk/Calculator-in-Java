package onlineShop;

import onlineShop.products.Book;

public class MainClass {

	public static void main(String[] args) {
		/*The complete name of a class (the�qualified name�) 
		 * for the Java runtime environment is obtained 
		 * from the package of the class 
		 * and the name of the class. 
		 * The name under which the class can be addressed
		 * from outside the package is �onlineshop.users.Customer.�
		 * */
		onlineShop.users.Customer myCustomer = new onlineShop.users.Customer(); 
		
		
		
//		Book myBook01 = new Book();
//		myBook01.
		
		

	}//main

}//class
