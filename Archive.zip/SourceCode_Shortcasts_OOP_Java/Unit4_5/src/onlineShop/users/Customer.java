package onlineShop.users;

public class Customer {

}
